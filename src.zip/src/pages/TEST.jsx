
export const test = () => {
    const data = "test";

    return (
        <>{data}</>
    )
}