import styled from "styled-components";

export const FormContainer = styled.div`max-width: 400px; margin: auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); text-align: center;`;
export const Title = styled.h2`margin-bottom: 20px; color: #1e3a8a;`;
export const Form = styled.form`display: flex; flex-direction: column; gap: 10px;`;
export const Label = styled.label`text-align: left; font-size: 14px; font-weight: bold;`;
export const Input = styled.input`padding: 10px; border: 1px solid #ccc; border-radius: 8px; font-size: 14px; width: 100%; box-sizing: border-box; &:focus { border-color: #1e3a8a; outline: none; }`;
export const ProfilePhotoPreview = styled.img`width: 80px; height: 80px; border-radius: 50%; object-fit: cover; margin: 10px auto; display: block;`;
export const SubmitButton = styled.button`background: #1e3a8a; color: white; padding: 12px; border: none; border-radius: 8px; font-size: 16px; cursor: pointer; transition: background 0.3s; &:hover { background: #3b82f6; }`;
export const ErrorMessage = styled.div`color: red; font-size: 14px; margin-top: 10px;`;
export const ForgotPassword = styled.p`font-size: 14px; margin-top: 10px; a { color: #1e3a8a; text-decoration: none; font-weight: bold; &:hover { text-decoration: underline; } }`;
