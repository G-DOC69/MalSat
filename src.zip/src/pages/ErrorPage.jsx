import React from 'react';

const ErrorPage = () => {
    return (
        <div>
            error
        </div>
    );
};

export default ErrorPage;
