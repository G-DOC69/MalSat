import styled from "styled-components";

export const Container = styled.div`display: flex; flex-wrap: wrap; gap: 20px; padding: 20px; max-width: 800px; margin: auto;`;
export const FormSection = styled.div`flex: 1; min-width: 300px;`;
export const Title = styled.h2`font-size: 24px; color: #1e3a8a;`;
export const Label = styled.label`display: flex; flex-direction: column; margin-bottom: 10px; font-weight: bold;`;
export const Input = styled.input`padding: 8px; border: 1px solid #ccc; border-radius: 5px; font-size: 16px;`;
export const TextArea = styled.textarea`padding: 8px; border: 1px solid #ccc; border-radius: 5px; font-size: 16px; min-height: 80px;`;
export const Button = styled.button`background: #1e3a8a; color: white; padding: 10px; border: none; border-radius: 8px; font-size: 16px; cursor: pointer; transition: background 0.3s; width: 100%; &:hover { background: #3b82f6; }`;
export const PhotoSection = styled.div`flex: 1; min-width: 300px; text-align: center;`;
export const PhotoPreview = styled.div`display: flex; gap: 5px; flex-wrap: wrap; justify-content: center;`;
export const Photo = styled.img`width: 80px; height: 80px; object-fit: cover; border-radius: 8px;`;
