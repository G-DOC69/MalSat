import './ChangeAdPageStyle'
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {getAnimalsListR} from "../../app/tempApi.js";
import {useCheckUser} from "../../hooks/useCheckUser.js";
import {getAdRequest, updateAdRequest} from "../../app/api.js";
import {
    Container,
    FormSection,
    Title
} from "./ChangeAdPageStyle.js";
import AdEditForm from "../../components/AdEditForm";
import {handleAdFormChange, handleAdPhotoUpload} from "../../app/store.js";
import PhotoPreviewBlock from "../../components/PhotoPreviewBlock";

const ChangeAdPage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        animal: '',
        breed: '',
        age: '',
        price: '',
        description: '',
        seller:{
            id:'',
            name:'',
            phone:'',
            profilePic:'',
        },
        photos: [],
    });
    const [animals, setAnimals] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const token = localStorage.getItem('access_token');
    const [previewPhotos,setPreviewPhotos]=useState([]);

    useCheckUser()

    useEffect(() => {
        const fetchAdData = async () => {
            try {
                const adData = await getAdRequest(id,token);
                let animalsList = await getAnimalsListR(token);
                setAnimals(animalsList.data);
                setFormData({
                    animal: adData.data.animal,
                    breed: adData.data.breed,
                    age: adData.data.age,
                    price: adData.data.price,
                    description: adData.data.description,
                    seller:adData.data.seller,
                    photos: adData.data.photos,
                });
            } catch (err) {
                setError(err||'Ошибка загрузки объявления.');
            }
        };
        fetchAdData().then(() => {});
    }, [id]);

    const onPhotoChange = (e) => {
        handleAdPhotoUpload(e, formData, setFormData, setPreviewPhotos, setError);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);
        try {
            const response = await updateAdRequest(id,token, formData);
            if (response.status === 200 || response.status === 201) {
                navigate('/ad/my-ads');
            }
        } catch (err) {
            setError(err.message||'Ошибка обновления объявления.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Container>
            {/* Форма редактирования */}
            <FormSection>
                <Title>Редактировать объявление</Title>
                <AdEditForm
                    formData={formData}
                    animals={animals}
                    handleChange={(e) => handleAdFormChange(e, setFormData)}
                    onPhotoChange={onPhotoChange}
                    handleSubmit={handleSubmit}
                    loading={loading}
                    error={error}
                />
            </FormSection>
            <PhotoPreviewBlock previewPhotos={previewPhotos}/>
        </Container>
    );
};

export default ChangeAdPage;
