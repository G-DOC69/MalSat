import { Form, Label, Input, SubmitButton } from "../pages/changeprofile/ChangeProfilePageStyle.js";

const ProfileForm = ({ formData = {}, handleChange, handlePhotoChange }) => (
    <Form>
        <Label>Имя пользователя:</Label>
        <Input type="text" name="username" value={formData.username || ''} onChange={handleChange} required />

        <Label>Фото профиля:</Label>
        <Input type="file" name="photo" accept="image/*" onChange={handlePhotoChange} />

        <Label>Адрес Электронной почты:</Label>
        <Input type="email" name="email" value={formData.email || ''} onChange={handleChange} required />

        <Label>Номер телефона:</Label>
        <Input type="text" name="phone" value={formData.phone || ''} onChange={handleChange} required />

        <Label>Пароль (для подтверждения):</Label>
        <Input type="password" name="password" value={formData.password || ''} onChange={handleChange} required />

        <SubmitButton type="submit">Сохранить изменения</SubmitButton>
    </Form>
);

export default ProfileForm;
