import { AdCardStyled, AdImage, AdTitle, AdText } from "../pages/allads/AllAdsPageStyle.js";
import { calculateAgeInMonths, calculateAgeInYears } from "../app/store.js";

const AdCard = ({ ad, navigate }) => {
        if (!ad) return null;

        return (
            <AdCardStyled onClick={() => navigate(`/ad/${ad.id}`)}>
                    <AdImage src={ad.photoUrl || '/placeholder.jpg'} alt={ad.breed || "Животное"} />
                    <AdTitle>{ad.breed} ({ad.animal})</AdTitle>
                    <AdText>Возраст: {calculateAgeInMonths(ad.age)} месяцев ({calculateAgeInYears(calculateAgeInMonths(ad.age))})</AdText>
                    <AdText>Регион: {ad.region}</AdText>
                    <AdText><strong>{ad.price} сом</strong></AdText>
            </AdCardStyled>
        );
};

export default AdCard;
