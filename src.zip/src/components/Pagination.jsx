import { PaginationStyled, PageButton } from "../pages/allads/AllAdsPageStyle.js";

const handleNextPage = (page, itemsPerPage, totalItems, setPage) => {
    const nextPage = page + 1;
    if ((nextPage - 1) * itemsPerPage < totalItems) {
        setPage(nextPage);
    }
};

const handlePrevPage = (page, setPage) => {
    if (page > 1) {
        setPage(page - 1);
    }
};

const Pagination = ({ page, totalPages, totalItems, itemsPerPage, setPage }) => (
    <PaginationStyled>
        <PageButton onClick={() => handlePrevPage(page, setPage)} disabled={page === 1}>← Назад</PageButton>
        <p>{page} / {totalPages}</p>
        <PageButton onClick={() => handleNextPage(page, itemsPerPage, totalItems, setPage)} disabled={page * itemsPerPage >= totalItems}>Вперед →</PageButton>
    </PaginationStyled>
);

export default Pagination;
