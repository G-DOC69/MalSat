import { Button, Label, Input, TextArea } from "../pages/changead/ChangeAdPageStyle.js";

const AdEditForm = ({ formData, animals = [], handleChange, onPhotoChange, handleSubmit, loading, error }) => (
    <form onSubmit={handleSubmit}>
        {error && <div className="error-message">{error}</div>}

        <Label>
            Животное:
            <select name="animal" value={formData.animal} onChange={handleChange} required>
                <option value="">Выберите животное</option>
                {animals.map((animal) => (
                    <option key={animal} value={animal}>{animal}</option>
                ))}
            </select>
        </Label>

        <Label>
            Порода:
            <Input name="breed" value={formData.breed} onChange={handleChange} required />
        </Label>

        <Label>
            Возраст:
            <Input type="date" name="age" value={formData.age} onChange={handleChange} required />
        </Label>

        <Label>
            Цена (KGS):
            <Input type="number" name="price" value={formData.price} onChange={handleChange} required />
        </Label>

        <Label>
            Описание:
            <TextArea name="description" value={formData.description} onChange={handleChange} maxLength="2000" required />
        </Label>

        <Label>
            Фото (макс. 10):
            <Input type="file" multiple accept="image/*" onChange={onPhotoChange} />
        </Label>

        <Button type="submit" disabled={loading}>
            {loading ? 'Загрузка...' : 'Сохранить изменения'}
        </Button>
    </form>
);

export default AdEditForm;
