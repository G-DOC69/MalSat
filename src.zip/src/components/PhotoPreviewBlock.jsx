import { PhotoSection, PhotoPreview, Photo } from "../pages/changead/ChangeAdPageStyle.js";

const PhotoPreviewBlock = ({ previewPhotos = [] }) => (
    <PhotoSection>
        <h3>Текущие и новые фото</h3>
        <PhotoPreview>
            {previewPhotos.length > 0 ? (
                previewPhotos.map((src, index) => (
                    <Photo key={index} src={src} alt="Preview" />
                ))
            ) : (
                <p>Фото еще не загружены</p>
            )}
        </PhotoPreview>
    </PhotoSection>
);

export default PhotoPreviewBlock;
