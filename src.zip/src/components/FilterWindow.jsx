import { Label, Select, Input, Filters } from "../pages/allads/AllAdsPageStyle.js";
import { uniqueAges, uniqueValues } from "../app/store.js";

const FilterWindow = ({ filter, setFilter, ads = [] }) => (
    <Filters>
        <Label>
            Животное:
            <Select value={filter.animal} onChange={e => setFilter({ ...filter, animal: e.target.value, breed: "" })}>
                <option value="">Любое</option>
                {uniqueValues(ads, "animal").map(animal => (
                    <option key={animal} value={animal}>{animal}</option>
                ))}
            </Select>
        </Label>

        <Label>
            Порода:
            <Select value={filter.breed} disabled={!filter.animal} onChange={e => setFilter({ ...filter, breed: e.target.value })}>
                <option value="">Любая</option>
                {uniqueValues(ads, "breed")
                    .filter(breed => ads.find(ad => ad.animal === filter.animal && ad.breed === breed))
                    .map(breed => (
                        <option key={breed} value={breed}>{breed}</option>
                    ))}
            </Select>
        </Label>

        <Label>
            Возраст от:
            <Select value={filter.minAge} onChange={e => setFilter({ ...filter, minAge: Number(e.target.value) })}>
                <option value="">-</option>
                {uniqueAges(ads).map(age => (
                    <option key={age} value={age}>{age} месяцев</option>
                ))}
            </Select>
        </Label>

        <Label>
            до:
            <Select value={filter.maxAge} onChange={e => setFilter({ ...filter, maxAge: Number(e.target.value) })}>
                <option value="">-</option>
                {uniqueAges(ads).map(age => (
                    <option key={age} value={age}>{age} месяцев</option>
                ))}
            </Select>
        </Label>

        <Label>
            Регион:
            <Select value={filter.region} onChange={e => setFilter({ ...filter, region: e.target.value })}>
                <option value="">Все</option>
                {uniqueValues(ads, "region").map(region => (
                    <option key={region} value={region}>{region}</option>
                ))}
            </Select>
        </Label>

        <Label>
            Цена от:
            <Input type="number" value={filter.minPrice} onChange={e => setFilter({ ...filter, minPrice: e.target.value })} />
        </Label>

        <Label>
            до:
            <Input type="number" value={filter.maxPrice} onChange={e => setFilter({ ...filter, maxPrice: e.target.value })} />
        </Label>
    </Filters>
);

export default FilterWindow;
