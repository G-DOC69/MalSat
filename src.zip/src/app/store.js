// --- Filtering logic ---
export const applyFilters = (filter, ads, setTotalItems, setFilteredAds, itemsPerPage, page) => {
    const filtered = ads.filter(ad =>
        (!filter.animal || ad.animal?.toLowerCase() === filter.animal.toLowerCase()) &&
        (!filter.breed || ad.breed?.toLowerCase() === filter.breed.toLowerCase()) &&
        (!filter.minAge || checkMinAge(calculateAgeInMonths(ad.age), filter.minAge, ads)) &&
        (!filter.maxAge || checkMaxAge(calculateAgeInMonths(ad.age), filter.maxAge, ads)) &&
        (!filter.region || ad.region?.toLowerCase() === filter.region.toLowerCase()) &&
        (!filter.minPrice || ad.price >= parseInt(filter.minPrice, 10)) &&
        (!filter.maxPrice || ad.price <= parseInt(filter.maxPrice, 10))
    );

    setTotalItems(filtered.length);

    const startIndex = (page - 1) * itemsPerPage;
    const paginated = filtered.slice(startIndex, startIndex + itemsPerPage);
    setFilteredAds(paginated);
};

// --- Calculate ad age in months ---
export const calculateAgeInMonths = (birthDate) => {
    if (!birthDate) return 0;
    const birth = new Date(birthDate);
    const today = new Date();
    return (today.getFullYear() - birth.getFullYear()) * 12 + (today.getMonth() - birth.getMonth());
};

// --- Human-readable age display (in Russian) ---
export const calculateAgeInYears = (months) => {
    const years = Math.floor(months / 12);
    if (years === 1) return '1 год';
    if (years >= 2 && years <= 4) return `${years} года`;
    return `${years} лет`;
};

// --- Check if ad's age fits minimum ---
export const checkMinAge = (adAge, minAge, ads) => {
    const ageOrder = uniqueAges(ads);
    return ageOrder.indexOf(adAge) >= ageOrder.indexOf(minAge);
};

// --- Check if ad's age fits maximum ---
export const checkMaxAge = (adAge, maxAge, ads) => {
    const ageOrder = uniqueAges(ads);
    return ageOrder.indexOf(adAge) <= ageOrder.indexOf(maxAge);
};

// --- Get sorted unique age list ---
export const uniqueAges = (ads) => {
    return [...new Set(ads.map(ad => calculateAgeInMonths(ad.age)))].sort((a, b) => a - b);
};

// --- Get unique values from ad fields (like animals, breeds, etc) ---
export const uniqueValues = (ads, key) => {
    return [...new Set(ads.map(ad => ad[key]))];
};

// --- Handle form field changes ---
export const handleAdFormChange = (e, setFormData) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
};

// --- Handle photo upload for ads ---
export const handleAdPhotoUpload = (e, formData, setFormData, setPreviewPhotos, setError) => {
    const files = Array.from(e.target.files);

    if (files.length + formData.photos.length > 10) {
        setError('Максимум 10 фото!');
        return;
    }

    const previews = files.map(file => URL.createObjectURL(file));
    setPreviewPhotos(prev => [...prev, ...previews]);
    setFormData(prev => ({
        ...prev,
        photos: [...prev.photos, ...files]
    }));
};
