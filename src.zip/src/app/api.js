import axios from 'axios';

axios.defaults.baseURL = 'http://localhost:8080/api';

const setAuthToken = (token) => {
    if (token) {
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    } else {
        delete axios.defaults.headers.common['Authorization'];
    }
};

// --- Advertisement related requests ---
export const fetchTopAdsRequest = () => axios.get('/ad/top-ads');

export const getAllAdsRequest = () => axios.get('/ad/all-ads');

export const getFavoriteAdsRequest = (token) => {
    setAuthToken(token);
    return axios.get('/ad/favorite-ads');
};

export const getUserAdsRequest = (token) => {
    setAuthToken(token);
    return axios.get('/ad/user-ads/my-ads');
};

export const getAdRequest = (id, token) => {
    setAuthToken(token);
    return axios.get(`/ad/${id}`);
};

export const updateAdRequest = (id, token, formData) => {
    setAuthToken(token);
    return axios.put(`/ad/change/${id}`, formData);
};

export const postAdRequest = (token, formData) => {
    setAuthToken(token);
    return axios.post('/ad/post', formData);
};

export const getAnimalsListRequest = (token) => {
    setAuthToken(token);
    return axios.get('/ad/animals-list');
};

export const getAdsByUserIdRequest = (id, token) => {
    setAuthToken(token);
    return axios.get(`/ad/user-ads/${id}`);
};

// --- Notifications ---
export const getUserNotificationsRequest = (token) => {
    setAuthToken(token);
    return axios.get('/notifications/user/notifications');
};

// --- Authentication (login/register/reset) ---
export const loginUserRequest = (formData) => axios.post('/users/login/sign-in', formData);

export const registerUserRequest = (formData) => axios.post('/users/login/register', formData);

export const sendPasswordResetRequest = (formData) => axios.post('/users/login/change-password', formData);

// --- Profile ---
export const updateUserProfileRequest = (token, formData) => {
    setAuthToken(token);
    return axios.put('/user/change', formData);
};

export const getUserRequest = (token) => {
    setAuthToken(token);
    return axios.get('/users/user/profile/my-profile');
};

export const getUserByIdRequest = (id, token) => {
    setAuthToken(token);
    return axios.get(`/users/user/profile/${id}`);
};

// --- Chat related ---
export const createChatRequest = (advertisementId, token) => {
    setAuthToken(token);
    return axios.post('/chats/create', { advertisementId });
};

export const getChatByIdRequest = (id, token) => {
    setAuthToken(token);
    return axios.get(`/chats/chat/${id}`);
};

export const getNewMessagesCountRequest = (token) => {
    setAuthToken(token);
    return axios.get('/user/messages');
};

export const sendMessageRequest = (chatId, token, messageData) => {
    setAuthToken(token);
    return axios.post(`/messages/${chatId}`, messageData);
};
